package com.astratech.registry;

import com.astratech.world.CraterFeature;
import com.astratech.world.OutpostFeature;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;

public final class ModFeatures {
	public static final Feature<DefaultFeatureConfig> CRATER = Registry.register(Registries.FEATURE,
		new Identifier("astratech", "crater"), new CraterFeature(DefaultFeatureConfig.CODEC));
	public static final Feature<DefaultFeatureConfig> OUTPOST = Registry.register(Registries.FEATURE,
		new Identifier("astratech", "outpost"), new OutpostFeature(DefaultFeatureConfig.CODEC));

	private ModFeatures() {
	}

	public static void init() {
	}
}
