package com.astratech.item;

import com.astratech.material.AstralToolMaterial;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

/** Plasma Blade: arc damage + slow on hit, right-click for a shockwave. */
public class AstralSwordItem extends SwordItem {
	public AstralSwordItem(Settings settings) {
		super(AstralToolMaterial.INSTANCE, 3, -2.2f, settings);
	}

	@Override
	public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
		boolean result = super.postHit(stack, target, attacker);
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2));
		if (attacker instanceof PlayerEntity player) {
			target.damage(attacker.getDamageSources().indirectMagic(attacker, attacker), 4.0f);
		}
		return result;
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);
		if (player.getItemCooldownManager().isCoolingDown(this)) {
			return TypedActionResult.pass(stack);
		}
		if (!world.isClient && world instanceof ServerWorld serverWorld) {
			Box box = player.getBoundingBox().expand(6.0, 2.0, 6.0);
			for (LivingEntity entity : world.getEntitiesByClass(LivingEntity.class, box, e -> e != player && e.isAlive() && !e.isTeammate(player))) {
				entity.damage(player.getDamageSources().playerAttack(player), 10.0f);
				double dx = entity.getX() - player.getX();
				double dz = entity.getZ() - player.getZ();
				entity.takeKnockback(1.2, -dx, -dz);
			}
			serverWorld.spawnParticles(ParticleTypes.SWEEP_ATTACK, player.getX(), player.getBodyY(0.5), player.getZ(), 24, 3.0, 0.3, 3.0, 0.0);
			serverWorld.spawnParticles(ParticleTypes.ELECTRIC_SPARK, player.getX(), player.getBodyY(0.5), player.getZ(), 60, 3.0, 0.5, 3.0, 0.4);
			world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 0.4f, 2.0f);
			stack.damage(4, player, p -> p.sendToolBreakStatus(hand));
		}
		player.getItemCooldownManager().set(this, 160);
		return TypedActionResult.success(stack, world.isClient);
	}
}
