package com.astratech.item;

import com.astratech.entity.PlasmaBoltEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Ranged end-game weapon: fires fast plasma bolts. */
public class PulseBlasterItem extends Item {
	public PulseBlasterItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);
		if (player.getItemCooldownManager().isCoolingDown(this)) {
			return TypedActionResult.pass(stack);
		}
		world.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.PLAYERS, 0.6f, 2.0f);
		if (!world.isClient) {
			PlasmaBoltEntity bolt = new PlasmaBoltEntity(world, player);
			bolt.setDamage(16.0f);
			bolt.setVelocity(player, player.getPitch(), player.getYaw(), 0.0f, 3.2f, 0.2f);
			world.spawnEntity(bolt);
			stack.damage(1, player, p -> p.sendToolBreakStatus(hand));
		}
		player.getItemCooldownManager().set(this, 7);
		return TypedActionResult.success(stack, world.isClient);
	}
}
