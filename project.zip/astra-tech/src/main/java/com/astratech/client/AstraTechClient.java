package com.astratech.client;

import com.astratech.client.model.AstroBotModel;
import com.astratech.client.model.LunarHopperModel;
import com.astratech.client.model.ModModelLayers;
import com.astratech.client.model.NovaOvermindModel;
import com.astratech.client.model.PlasmaDroneModel;
import com.astratech.client.render.AstroBotRenderer;
import com.astratech.client.render.LunarHopperRenderer;
import com.astratech.client.render.LunarSentinelRenderer;
import com.astratech.client.render.NovaOvermindRenderer;
import com.astratech.client.render.PlasmaDroneRenderer;
import com.astratech.client.render.VoidStalkerRenderer;
import com.astratech.client.screen.CodexScreen;
import com.astratech.client.sky.MoonEffects;
import com.astratech.client.sky.MoonSky;
import com.astratech.item.AstraCodexItem;
import com.astratech.logic.ArmorAbilities;
import com.astratech.net.ModNetworking;
import com.astratech.registry.ModBlocks;
import com.astratech.registry.ModEntities;
import com.astratech.registry.ModWorlds;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public class AstraTechClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Model layers
		EntityModelLayerRegistry.registerModelLayer(ModModelLayers.PLASMA_DRONE, PlasmaDroneModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(ModModelLayers.ASTRO_BOT, AstroBotModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(ModModelLayers.LUNAR_HOPPER, LunarHopperModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(ModModelLayers.NOVA_OVERMIND, NovaOvermindModel::getTexturedModelData);

		// Entity renderers
		EntityRendererRegistry.register(ModEntities.LUNAR_SENTINEL, LunarSentinelRenderer::new);
		EntityRendererRegistry.register(ModEntities.VOID_STALKER, VoidStalkerRenderer::new);
		EntityRendererRegistry.register(ModEntities.PLASMA_DRONE, PlasmaDroneRenderer::new);
		EntityRendererRegistry.register(ModEntities.ASTRO_BOT, AstroBotRenderer::new);
		EntityRendererRegistry.register(ModEntities.LUNAR_HOPPER, LunarHopperRenderer::new);
		EntityRendererRegistry.register(ModEntities.NOVA_OVERMIND, NovaOvermindRenderer::new);
		EntityRendererRegistry.register(ModEntities.PLASMA_BOLT, context -> new FlyingItemEntityRenderer<>(context, 1.6f, true));

		// Blocks
		BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.LUNAR_PORTAL, RenderLayer.getTranslucent());

		// Moon sky
		DimensionRenderingRegistry.registerDimensionEffects(new Identifier("astratech", "moon"), new MoonEffects());
		DimensionRenderingRegistry.registerSkyRenderer(ModWorlds.MOON, new MoonSky());
		DimensionRenderingRegistry.registerCloudRenderer(ModWorlds.MOON, context -> {
		});
		DimensionRenderingRegistry.registerWeatherRenderer(ModWorlds.MOON, context -> {
		});

		// Codex
		AstraCodexItem.clientOpener = () -> MinecraftClient.getInstance().setScreen(new CodexScreen());

		// Ion thrusters: hold jump in the air; sneak + jump to hover.
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			ClientPlayerEntity player = client.player;
			if (player == null || client.isPaused() || client.world == null) {
				return;
			}
			if (ArmorAbilities.hasChest(player) && client.options.jumpKey.isPressed() && !player.isOnGround()
				&& !player.isTouchingWater() && !player.getAbilities().flying && !player.hasVehicle() && !player.isFallFlying()) {
				Vec3d velocity = player.getVelocity();
				double vy = player.isSneaking() ? 0.0 : Math.min(velocity.y + 0.1, 0.42);
				player.setVelocity(velocity.x, vy, velocity.z);
				player.fallDistance = 0.0f;
				double yawRad = Math.toRadians(player.getYaw());
				double sideX = -Math.cos(yawRad) * 0.22;
				double sideZ = -Math.sin(yawRad) * 0.22;
				for (int side = -1; side <= 1; side += 2) {
					client.world.addParticle(ParticleTypes.END_ROD, player.getX() + sideX * side, player.getY() + 0.8, player.getZ() + sideZ * side, 0.0, -0.25, 0.0);
				}
				client.world.addParticle(ParticleTypes.ELECTRIC_SPARK, player.getX(), player.getY() + 0.2, player.getZ(), 0.0, -0.2, 0.0);
				ClientPlayNetworking.send(ModNetworking.THRUST, PacketByteBufs.create());
			}
		});
	}
}
