package com.astratech.entity;

import com.astratech.registry.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.ProjectileAttackGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.mob.RangedAttackMob;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** Friendly support robot: heals nearby players and shoots hostile lunar creatures. */
public class AstroBotEntity extends PathAwareEntity implements RangedAttackMob {
	public AstroBotEntity(EntityType<? extends AstroBotEntity> type, World world) {
		super(type, world);
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return PathAwareEntity.createMobAttributes()
			.add(EntityAttributes.GENERIC_MAX_HEALTH, 60.0)
			.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
			.add(EntityAttributes.GENERIC_ARMOR, 8.0)
			.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0);
	}

	@Override
	protected void initGoals() {
		this.goalSelector.add(0, new SwimGoal(this));
		this.goalSelector.add(1, new ProjectileAttackGoal(this, 1.0, 20, 16.0f));
		this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
		this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
		this.goalSelector.add(7, new LookAroundGoal(this));
		this.targetSelector.add(1, new ActiveTargetGoal<>(this, HostileEntity.class, 5, true, false, e -> true));
	}

	@Override
	public void tickMovement() {
		super.tickMovement();
		if (!this.getWorld().isClient && this.age % 40 == 0) {
			for (PlayerEntity player : this.getWorld().getEntitiesByClass(PlayerEntity.class, this.getBoundingBox().expand(8.0), p -> p.isAlive() && !p.isSpectator())) {
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 80, 1, true, true));
				if (this.getWorld() instanceof ServerWorld serverWorld) {
					serverWorld.spawnParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getBodyY(0.8), player.getZ(), 4, 0.3, 0.3, 0.3, 0.0);
				}
			}
		}
	}

	@Override
	public ActionResult interactMob(PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);
		if (stack.isOf(ModItems.PLASMA_CRYSTAL)) {
			if (!this.getWorld().isClient) {
				this.heal(30.0f);
				if (!player.getAbilities().creativeMode) {
					stack.decrement(1);
				}
				if (this.getWorld() instanceof ServerWorld serverWorld) {
					serverWorld.spawnParticles(ParticleTypes.HEART, this.getX(), this.getBodyY(1.0), this.getZ(), 6, 0.4, 0.4, 0.4, 0.0);
				}
				this.getWorld().playSound(null, this.getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.NEUTRAL, 0.8f, 1.8f);
			}
			return ActionResult.success(this.getWorld().isClient);
		}
		return super.interactMob(player, hand);
	}

	@Override
	public void shootAt(LivingEntity target, float pullProgress) {
		PlasmaBoltEntity bolt = new PlasmaBoltEntity(this.getWorld(), this);
		bolt.setDamage(10.0f);
		double dx = target.getX() - this.getX();
		double dy = target.getBodyY(0.5) - this.getEyeY();
		double dz = target.getZ() - this.getZ();
		bolt.setVelocity(dx, dy, dz, 2.0f, 1.0f);
		this.getWorld().playSound(null, this.getBlockPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.NEUTRAL, 0.6f, 2.0f);
		this.getWorld().spawnEntity(bolt);
	}

	@Override
	public boolean canImmediatelyDespawn(double distanceSquared) {
		return false;
	}
}
